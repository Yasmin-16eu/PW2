const fs = require('fs').promises;
const http = require('http');

const server = http.createServer(async (req, res) => {

  let html;

  try {

    // Define headers padrão
    res.writeHead(200, { 'Content-Type': 'text/html' });

    // Verifica a rota acessada
    if (req.url === '/') {

      html = `
      <h1>e pra aparecer o html</h1>
      <p>To mt feliz que deu certo</p>
      `;

    } else {

      html = await fs.readFile('./public/404.html', 'utf-8');
      res.statusCode = 404;

    }

    res.end(html);

  } catch (erro) {

    // Erro interno do servidor
    res.statusCode = 500;

    res.end(JSON.stringify({
      erro: 'Erro ao ler arquivo'
    }));

  }

});

// Servidor escutando na porta 3000
server.listen(3000, () => {
  console.log('Servidor rodando em http://localhost:3000');
});